import React, { useState } from "react";
import {
	InputSearchOrder,
	SearchIcon,
	SearchOrderWrap,
	SearchProductBoxDeleteInputBtn,
	SearchProductBoxSearchBtn,
} from "./styled/StyledOrderManagement";

export default function OrderSearchPanel(props: {
	filterKeyword: string | null | undefined;
	doFilterKeyword: ((val: string | null) => void) | undefined;
}) {
	const [text, setText] = useState(props.filterKeyword);
	const onTextChange = (e: React.ChangeEvent<HTMLInputElement>) => setText(e.target.value);
	const onSearch = (val: string) => props.doFilterKeyword?.(val);
	const onTextKeypress = (e: React.KeyboardEvent<HTMLInputElement>) => {
		if (e.key === "Enter") {
			{
				text ? onSearch(text) : onSearch("");
			}
		}
	};
	const onIconClicked = () => {
		text ? onSearch(text) : onSearch("");
	};
	return (
		<SearchOrderWrap>
			<>
				<SearchProductBoxSearchBtn onClick={onIconClicked}>
					<SearchIcon className="fa fa-search" />
				</SearchProductBoxSearchBtn>
			</>
			<InputSearchOrder
				type="text"
				value={text || ""}
				onChange={onTextChange}
				onKeyDown={onTextKeypress}
				placeholder="Nhập mã đơn hàng"
			/>
			{/* {text != "" && (
				<SearchProductBoxDeleteInputBtn onClick={onTextClear}>
					<img src="./static/img/deletesearch.png" />
				</SearchProductBoxDeleteInputBtn>
			)} */}
		</SearchOrderWrap>
	);
}
