import React, { useEffect, useState } from "react";
import { PageBody, PageCenter, PageInner, PageTitle, PageTitleInner } from "../../controls/components/form/Page";
import { OrderManagementListWrap, OrderManagementPageWrap } from "../../controls/components/tabsView/StyledTabsView";
import TabLinksView from "../../controls/components/tabsView/TabLinksView";
import OrderManagementAllTab from "./OrderManagementAllTab";
import OrderManagementCanceledTab from "./OrderManagementCanceledTab";
import OrderManagementPurchasedTab from "./OrderManagementPurchasedTab";
import OrderManagementSettledTab from "./OrderManagementSettledTab";
import Order from "../../../models/Order";
import Select, { SelectOptionType } from "react-select";
import { getListHookWrap } from "./hook/useGetListHook";
import useCommonListFunctions from "../../hooks/useCommonList/useCommonListFunctions";
import useFilterList, { statusList } from "./hook/useFilterList";
import OrderManagementList from "./OrderManagementList";
import useListSelectedItems from "../../hooks/useListSelectedItems";
import { FilterOrder, OrderFilterBox, OrderFilterBoxDate, OrderManagementPage } from "./styled/StyledOrderManagement";
import { SmSelectSearchBox, SmSelectSearchBoxOrder } from "../../controls/components/selectSearchBox/SelectSearchBox";
import DateRangeInput from "../../controls/components/dateRangeInput/DateRangeInput";
import DateRangeInputOrder from "../../controls/components/dateRangeInput/DateRangeInputv2";
import OrderFilter from "./OrderFilter";

export default function OrderManagementv2() {
	return (
		<OrderManagementPage>
			<PageCenter>
				<PageInner>
					<PageBody>
						<OrderFilter />
					</PageBody>
				</PageInner>
			</PageCenter>
			<OrderManagementListWrap>
				<OrderManagementList />
			</OrderManagementListWrap>
		</OrderManagementPage>
	);
}
